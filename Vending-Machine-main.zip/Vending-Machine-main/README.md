# Vending-Machine
Project in Verilog

There are design and test bench codes written.
Also output and waveform have been provided.
